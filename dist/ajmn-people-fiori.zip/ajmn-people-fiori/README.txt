AJMN People - SAPUI5 app
========================
The sandbox prototype of AJMN People (goals, alignment, appraisals, development, training needs,
approvals, reports, Admin Center), looking and behaving exactly as it does on the sandbox.
Sample data only; each browser keeps its own copy. No backend, no OData service.

App id (namespace):  ajmn.people
Start file:          index.html
Needs from SAPUI5:   sap.ui.core only (it uses no SAP controls, so it runs on any SAPUI5 version)

WHAT IS IN THIS FOLDER
  index.html        starts the app, loading SAPUI5 from https://ui5.sap.com
  manifest.json     app descriptor
  Component.js      the UI5 component
  model/People.js   the screens, rules and sample data
  css/people.css    the look

UPLOAD TO THE ABAP FRONT-END SERVER (needs a developer key and a transport or $TMP)
  1. Unzip this folder to your PC.
  2. SE38 -> run report /UI5/UI5_REPOSITORY_LOAD
  3. Name of SAPUI5 application: e.g. ZAJMNPEOPLE   -> Upload
  4. Choose this folder (the one that contains index.html), then give a description,
     package (e.g. $TMP or your Z package) and transport request.
  5. Activate. The app is then served at:
       https://<fiori-host>:<port>/sap/bc/ui5_ui5/sap/zajmnpeople/index.html
  Alternative: SE80 -> BSP Application -> create ZAJMNPEOPLE -> right-click -> Import ->
  Web Objects, or deploy with SAP Business Application Studio / "ui5 deploy" tooling.

PUT IT ON THE FIORI LAUNCHPAD
  URL tile (simplest, works on any system):
     Launchpad Designer -> your catalog -> add a static App Launcher tile
       Title:        AJMN People
       Target URL:   /sap/bc/ui5_ui5/sap/zajmnpeople/index.html
  Or a native app: target mapping with Application type "SAPUI5 Fiori App",
       URL /sap/bc/ui5_ui5/sap/zajmnpeople and ID (component) ajmn.people.
  The app draws its own header and side menu, so inside the launchpad shell you will see two headers.
  The URL tile opens it in its own page, which looks best.

IF USERS CANNOT REACH ui5.sap.com
  The app only needs the UI5 core library. In index.html, change the src= line to the system's own UI5:
       src="/sap/public/bc/ui5_ui5/1/resources/sap-ui-core.js"
  and the data-sap-ui-theme value to one the system has (for example sap_belize on old systems).
  This was not tested here.

NOTES
  - Use the person icon (top right) to switch demo persona and review cycle, and to reset the demo data.
  - The browser console may show one 404 for Component-preload.js. It is harmless.
  - Do not enter real employee data.
