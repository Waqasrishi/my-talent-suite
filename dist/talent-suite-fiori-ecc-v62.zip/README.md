# AJMN Goals v62 — SAP Fiori front end, SAP ECC back end, developer pack

The Goals app as it is on Canvas today (v62, 19 Nov 2026), packaged for an SAP team:
the UI5 app for the Fiori launchpad, everything the ECC side needs (tables, OData service, ABAP, roles),
the AI design, and the Canvas back end as a working reference.
**Nothing here has been run against a real ECC or Gateway system yet.**

```
 Fiori launchpad page  (app/webapp, UI5 component zajmn.hr.goals.hk)
        |  OData V2 JSON, CSRF token, same host
 SAP Gateway: ZAJMN_GOALS_SRV  (ecc/02, ecc/ZCL_ZAJMN_GOALS_DPC_EXT.abap)
        |  authority checks (ecc/03), lock EZAJMN_GOAL, number ranges
 ECC tables ZAJMN_GOAL / _ACT / _ATT / _PUSH / _CONTR / _LOG / _AILOG   (ecc/01)
        |  PERNR only: names and reporting lines read from PA0001 / PA0002 / HRP1001
 AI: five jobs (goal ideas, measures, review, return comments, translation) — ecc/04_ai.md
        option A: keep calling the company model behind Canvas (AJMN_CONFIG.aiUrl)
        option B: an ABAP function import calls the model through an SM59 destination
```

## What is in the zip

| Folder | What |
|---|---|
| `app/` | The Fiori project (UI5, `zajmn.hr.goals.hk`, **v62**). Same screens as Canvas. Two files differ: `model/Store.js` talks OData to ECC instead of the Canvas REST API, and `model/Scenario.js` carries a placeholder PERNR for each test person |
| `ecc/01_tables_SE11.md` | ECC tables, number ranges, lock object — including `ZAJMN_AILOG` |
| `ecc/02_gateway_service_SEGW.md` | Entity model of `ZAJMN_GOALS_SRV` and how to activate it |
| `ecc/ZCL_ZAJMN_GOALS_DPC_EXT.abap` | The service implementation, a starting point for the ABAP developer |
| `ecc/03_authorizations_and_ids.md` | PERNR as employee id, roles, authorization object, practice list |
| `ecc/04_ai.md` | **AI:** every AI job, its input and output, the prompts, logging, and how to run it next to ECC |
| `ecc/05_workflows_v62.md` | **Workflows as built in v62:** create, review, push down, edit, contribute, delete, progress, weights — and the log action codes |
| `developer/DEVELOPER.md` | **Tables and API side by side:** Canvas Postgres ↔ ECC tables ↔ OData entities; REST routes ↔ OData |
| `developer/` | The Canvas back end that runs v62 today: `server.mjs`, `api.mjs`, `db.mjs`, `ai.mjs`, `db/migrations/*.sql` (reference only, not for ECC) |
| `migration/` | Export the prototype's data to CSV in ECC format (`export-from-canvas.mjs`, `pernr-map.json`) and load it (`ZAJMN_IMPORT.abap`) |

## The order to do it in

1. **Personnel numbers.** Fill `migration/pernr-map.json` and the `pernr` values in `app/webapp/model/Scenario.js` with real PERNRs. Until then both hold placeholders starting with 9.
2. **ECC:** tables, number ranges and lock object (`ecc/01`); the service in SEGW (`ecc/02`); finish `ZCL_ZAJMN_GOALS_DPC_EXT`; roles (`ecc/03`). Test in `/IWFND/GW_CLIENT`.
3. **AI:** choose option A or B in `ecc/04_ai.md` with security and data protection. Without it the app still works; the AI parts fall back to the goal library and translation says the AI is not connected.
4. **First test:** set `window.AJMN_CONFIG = { serviceUrl: "/sap/opu/odata/sap/ZAJMN_GOALS_SRV", aiUrl: "<option A url or empty>" }` before UI5 loads (one line in `index.html`), create a goal, reload: it must still be there, and `ZAJMN_LOG` must have the rows.
5. **Move the data:** `node migration/export-from-canvas.mjs <canvas url> <cookie>`, load with `ZAJMN_IMPORT` (test run first), then raise the number ranges above the highest id.
6. **Launchpad:** deploy the UI5 app (`/UI5/UI5_REPOSITORY_LOAD`), target mapping `ZAJMNGOALS-display`, catalog, roles.

## What changed from the v49 pack

| Area | v49 pack | v62 (this pack) |
|---|---|---|
| Approval | Goals and changes waited for approval; change requests | Nothing waits. New, pushed and edited goals show **Awaiting review**; the approver approves or returns in one click, afterwards |
| Contributors | Link needed the owner's approval | Invitee gets **View goal / Decline / Accept**. Accept makes and links their own goal at once, then offers to tailor it with AI suggestions |
| Delete | Approved goals needed the approver; pushed copies were deleted too | Only that goal and the links to it go; pushed copies and other people's linked goals stay |
| AI | Ideas, measures, review, return comments | Plus **translation** (English ↔ Arabic page switch) and contributor goal suggestions |
| Screens | — | Full-width landscape alignment chart with goal popups, History popup, shorter goal page, restyled fields |

Status codes, contributor statuses and log actions for v62 are in `ecc/05_workflows_v62.md`; where `ecc/01` and `ecc/02` still mention approval steps, `ecc/05` wins.

## Still open (decide before go-live)

* **Workflow and compliance rules** are under discussion (19 Nov 2026): goal-setting window and lock date, minimum standard (3–5 goals, weights 100%), review deadline, who reviews the Director General, retention, who can see what. Build them in the service, not only in the page.
* The "Proxy Now" switch is for the demo. On ECC the service must decide from `SY-UNAME`; remove the switch before go-live.
* Attachments in `ZAJMN_ATT` (RAWSTRING) are for the pilot; production uses the content server or DMS.
* The ETag check for two people saving at once is marked in the ABAP, not written.
