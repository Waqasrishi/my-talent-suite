# AJMN Talent Suite as SAP Fiori apps: hand-over for the Fiori developer

Two SAPUI5 apps that run in the SAP Fiori launchpad and open each other. **Sample data only: no backend, no OData service, no database; nothing is saved.**

| | Goals | AJMN People home |
|---|---|---|
| Folder | `goals/` | `home/` |
| Component ID | `zajmn.hr.goals.hk` | `zajmn.hr.sucfac1.hk` |
| Launchpad intent | `ZAJMNGOALS-display` | `ZAJMNHR-display` |
| Suggested ABAP name (15 characters at most) | `ZAJMN_HR_GOALS` | `ZAJMN_HR_HOME` |
| Ready to upload | `abap-upload/ZAJMN_HR_GOALS.zip` | `abap-upload/ZAJMN_HR_HOME.zip` |

The Goals app takes the launchpad parameter `start` (`new`, `align`, `dash`, `goal`, `approvals`) to open a given screen: `#ZAJMNGOALS-display?start=new`.

## What was tested

I ran both apps in the SAPUI5 **sandbox launchpad** (SAPUI5 1.144.1, theme sap_horizon), source and the built, minified version (`Component-preload.js`):
- Home opens; "Goals 2027" in the menu and the home page's Goals cards open the Goals app by launchpad navigation; the home icon goes back; `?start=new` and `?start=approvals` open the right screen.
- Opening an app a second time (home, Goals, home, Goals) works.
- A goal can be created, the sections open, the English / Arabic switch and the Proxy Now dialog work.
- No failed requests apart from the sandbox launchpad's own search calls.

**Not tested:** a real ABAP front-end server, SAP BTP, or SAP Business Application Studio / Web IDE. Where the steps below depend on your system, they follow the standard SAP procedure.

## 1. Put the apps on the ABAP front-end server

**Option A: upload the zips.** Run the report `/UI5/UI5_REPOSITORY_LOAD` (SE38). For each zip: upload, choose the ABAP name above, a package and a transport. Each zip has the app files at its root (`Component-preload.js`, `manifest.json` and so on), which is what the report expects. The apps are then served at `/sap/bc/ui5_ui5/sap/zajmn_hr_goals` and `/sap/bc/ui5_ui5/sap/zajmn_hr_home`.

**Option B: SAP Fiori tools.** In each folder: `npm install`, edit `ui5-deploy.yaml` (system URL, client, package, transport), then `npm run deploy`.

Check: the ICF node `/sap/bc/ui5_ui5/sap/` is active, and the system serves `.woff2` and `.ttf` files (the company fonts are in `webapp/fonts`). If a font does not load, add the MIME types `font/woff2` and `font/ttf` for the repository.

## 2. Show them in the launchpad

For each app, in the launchpad content manager (or `LPD_CUST` and `/UI2/FLPD_CUST` on the front-end server):

1. **Semantic objects:** `ZAJMNHR` and `ZAJMNGOALS` (`/UI2/SEMOBJ`).
2. **Target mapping:** semantic object and action `display`, application type **SAPUI5 Fiori App**, URL `/sap/bc/ui5_ui5/sap/zajmn_hr_goals` (or `..._home`), **component ID** `zajmn.hr.goals.hk` (or `zajmn.hr.sucfac1.hk`), device types all, parameter `start` optional.
3. **Tile:** a static tile with the same semantic object and action (titles "Goals 2027" and "AJMN People"), in a catalog and group.
4. **Roles:** give **both** catalogs to the users' roles. If only one is given, the links between the apps say the target is not available.

The manifests already declare these inbounds (`sap.app > crossNavigation`) and the outbound links between the apps, so apps and tiles can also be created from the manifest.

## 3. Run it locally

```
cd goals        # or home
npm install
npm start       # SAPUI5 comes from ui5.sap.com; opens webapp/index.html
npm run build   # creates dist/ with Component-preload.js
```

**Both apps in a test launchpad.** Serve this folder with any web server and open `/flp-test/flpSandbox.html#ZAJMNHR-display` (for example `npx http-server .`). It needs internet for ui5.sap.com. It shows the navigation between the apps without a backend.

## 4. Things to know

- **Two headers in the launchpad.** Each app draws its own top bar, side menu and Goals section bar (the demo design). Inside the launchpad you see the SAP shell bar above them. If the design should drop its own top bar there, tell me and I will make a launchpad variant.
- **The left menu** (Home, My AI Assistant and so on) is the same in both apps; only Home and Goals 2027 lead anywhere. The other items say "not set up yet".
- **Languages:** English and Arabic. The switch translates the screen's own words (`webapp/model/I18n.js`); goal text is never translated. Arabic turns the page right to left.
- **Fonts:** the company Al Jazeera fonts only, in `webapp/fonts` and declared in `css/goals.css` and `css/home.css`.
- **Sample data** lives in `goals/webapp/model/Scenario.js` (30 people), `Goals.js` (goal library, example goals) and `home/webapp/model/Home.js`. To use real data, replace these with an OData model.
- **Minimum SAPUI5:** the manifests say 1.44; it was only run on 1.144. Use the newest your system has.
- **Proxy Now** (the avatar menu) imitates SuccessFactors: it switches the demo to another sample person; it grants nothing.
- **Smooth screens:** a screen that is drawn again is updated in place (`webapp/model/Morph.js`) instead of being rebuilt, so nothing flashes and the page keeps its height and scroll position. Moving to another screen or wizard step fades the content in and glides back to the top (`Motion.js`). All motion is switched off for people who prefer reduced motion.
- **Changes made for the launchpad** compared with the web demo: the apps can be opened again without a page reload (module state per drawn page), document listeners are removed when an app closes, the layout adjusts to the launchpad's shell bar, and the loading screen and prefetch of the web demo are not included.

## Folder map

```
goals/                 SAPUI5 project: package.json, ui5.yaml, ui5-deploy.yaml, webapp/
home/                  same for the home page
flp-test/              flpSandbox.html: both apps in a test launchpad
abap-upload/           built zips for /UI5/UI5_REPOSITORY_LOAD
HANDOVER-FIORI.md      this file
```
Inside each `webapp/`: `Component.js`, `manifest.json`, `view/App.view.xml`, `controller/App.controller.js` (the page markup and the menu), `model/` (screens and sample data), `util/Nav.js` (launchpad navigation), `css/`, `fonts/`, `i18n/i18n.properties`, `index.html` (stand-alone start page).
