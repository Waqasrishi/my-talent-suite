AJMN Talent Suite - SAP Fiori (SAPUI5) app
==========================================
Sandbox prototype. Synthetic data only; each browser keeps its own copy. No backend, no OData service.

App id (namespace):  ajmn.talent
Built and tested on: SAPUI5 1.144
Start file:          index.html

WHAT IS IN THIS FOLDER
  index.html            starts the app on its own, loading SAPUI5 1.144 from https://ui5.sap.com
  manifest.json         app descriptor
  Component.js          component
  model/Store.js        sample data, rules and actions
  controller/, view/    screens
  css/style.css         styling

UPLOAD TO THE ABAP FRONT-END SERVER (needs a developer key and a transport or $TMP)
  1. Unzip this folder to your PC.
  2. SE38 -> run report /UI5/UI5_REPOSITORY_LOAD
  3. Name of SAPUI5 application: e.g. ZTALENTSUITE   -> Upload
  4. Choose this folder (the one that contains index.html), then give a description,
     package (e.g. $TMP or your Z package) and transport request.
  5. Activate. The app is then served at:
       https://<fiori-host>:<port>/sap/bc/ui5_ui5/sap/ztalentsuite/index.html
  Alternative: SE80 -> BSP Application -> create ZTALENTSUITE -> right-click -> Import ->
  Web Objects, or deploy with SAP Business Application Studio / "ui5 deploy" tooling.

PUT IT ON THE FIORI LAUNCHPAD - TWO WAYS

  A. URL tile (works on ANY system UI5 version, design unchanged)   <- use this if unsure
     Launchpad Designer -> your catalog -> add a static App Launcher tile
       Title:        Talent Suite
       Target URL:   /sap/bc/ui5_ui5/sap/ztalentsuite/index.html
     The app opens with its own SAPUI5 1.144, independent of the server's version.
     Users' browsers must be able to reach https://ui5.sap.com. If they cannot, ask Basis to
     host the SAPUI5 1.144 runtime and change the src= line in index.html to that address.

  B. Native launchpad app (ONLY if the system's SAPUI5 is 1.144 or newer)
     Target mapping:
       Semantic object / action:  e.g. TalentSuite / display
       Application type:          SAPUI5 Fiori App
       URL:                       /sap/bc/ui5_ui5/sap/ztalentsuite
       ID (component):            ajmn.talent
     Then add a tile with the same semantic object and action.
     On an older system UI5 (for example 1.44) the app will not start this way: use A.

CHECK YOUR SYSTEM'S SAPUI5 VERSION
  Launchpad user menu -> About, or open
  https://<fiori-host>:<port>/sap/public/bc/ui5_ui5/1/resources/sap-ui-version.json

NOTES
  - "Reset sandbox" in the header restores the sample data.
  - Do not enter real employee data.
