#!/bin/sh
# Builds a working copy of the whole demo in ./demo-run (the folder layout server.mjs expects) and starts it on http://localhost:8080
# Needs Node 22. Usage:  cd 03-server-and-deploy && sh run-demo.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/.."; RUN="$HERE/demo-run"
rm -rf "$RUN"; mkdir -p "$RUN"
cp "$HERE/server.mjs" "$HERE/package.json" "$RUN/"
cp "$ROOT"/04-html-prototypes/*.html "$RUN/"
cp -R "$ROOT"/01-fiori-goals-module/zajmn.hr.goals.hk-v27 "$ROOT"/02-fiori-people-home/zajmn.hr.sucfac1.hk-v6 "$RUN/"
for d in "$ROOT"/07-earlier-versions/*/; do n="$(basename "$d")"; [ "$n" = "dist-zips" ] || cp -R "$d" "$RUN/$n"; done
cd "$RUN" && PORT="${PORT:-8080}" node server.mjs
