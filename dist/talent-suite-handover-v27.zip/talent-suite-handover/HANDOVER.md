# AJMN Talent Suite: hand-over for the Fiori developer

Date: 17 November 2026. Everything here is a clickable prototype with **sample data**. There is **no database, no backend and no OData service**: nothing is saved, and a browser refresh empties every goal.

## 1. What is in this package

| Folder | What it is |
|---|---|
| `01-fiori-goals-module/` | **The Goals app** (SAPUI5 component `zajmn.hr.goals.hk`, version 27). The project folder and the same folder as a zip for SAP Web IDE import. |
| `02-fiori-people-home/` | **The AJMN People home page** (component `zajmn.hr.sucfac1.hk`, version 6). Opens the Goals app. Project folder and zip. |
| `03-server-and-deploy/` | `server.mjs` (the small static web server that runs both apps on Canvas), `package.json`, `score.yaml` (Canvas deploy settings), `Procfile`. Only needed to run the demo the way it runs now. |
| `04-html-prototypes/` | The original single-page HTML prototypes, kept as the design reference: `index.html` (Talent Suite), `strategy.html` (Strategy Room), `successfactors.html` (SuccessFactors replica), `goals.html` and `home.html` (plain HTML Goals and Home), `goals-hub.html`, `goals-hub-v2.html`. |
| `05-fonts-source/` | The company Al Jazeera fonts as supplied (Latin and Arabic, all weights and formats). |
| `06-docs/` | `BRIEF.md` (what the app does) and `README.md`. |
| `07-earlier-versions/` | Every earlier version of both projects (goals v1 to v26, home v1 to v5), the first Fiori Talent Suite (`fiori/`, `fiori-people/`) and the old zips in `dist-zips/`. Nothing was deleted. |

## 2. The two Fiori apps and how they connect

| | Goals | AJMN People home |
|---|---|---|
| Component ID | `zajmn.hr.goals.hk` | `zajmn.hr.sucfac1.hk` |
| Launchpad intent | `ZAJMNGOALS-display` | `ZAJMNHR-display` |
| Needs | `sap.ui.core` only, minimum SAPUI5 1.44 (run here on 1.144) | same |
| Each project has | `README.txt` (import, run, deploy, launchpad target mapping and tile), `neo-app.json`, `webapp/` | same |

- The apps keep **separate sample data** and are joined by navigation only (cross-application navigation in the launchpad, or the `nav.home` URL in `manifest.json` outside it).
- Home opens Goals at a given place with `?start=` : `new` (New goal wizard), `align`, `dash`, `goal`, `approvals`. No parameter opens the goal list.
- Each app draws its **own header**, so inside a launchpad there are two headers. Both apps scope every CSS rule to their root class (`.ajmng` for Goals, `.ajmnh` for Home) so they cannot restyle the launchpad.
- Each project's `webapp/` is the standard Web IDE layout: `Component.js`, `manifest.json`, `view/App.view.xml`, `controller/App.controller.js` (builds the page markup), `model/` (the screens and the sample data), `util/Nav.js`, `css/`, `fonts/`, `i18n/i18n.properties`, `index.html` (Web IDE start page), `index-standalone.html` (runs anywhere, loading SAPUI5 from ui5.sap.com).

## 3. Where the "database" is (sample data in the code)

There is no database. All data is in these files:

| Data | File |
|---|---|
| The 30 people you can "view as" (1 Director General, 3 Executive Directors, 6 Directors, 8 Managers, 12 Employees), their level, label and approver | `01.../webapp/model/Scenario.js` (one table; edit it to add or remove people) |
| Goal library: 427 sample goal ideas with measure, area and typical start and target numbers | `01.../webapp/model/Goals.js`, constant `LIBT` |
| Other goal ideas and measure wording | `Goals.js`: `GOAL_IDEAS`, `DG_IDEAS`, `MEASURE_BANK` |
| Seeded detail for example goals (description, start date, target, updates, approvals, audit) | `Goals.js`: `SEED` |
| Goals created in a session | in memory only (`STORE`, `goals`); never saved |
| Screen words in English and Arabic | `01.../webapp/model/I18n.js` (table `D`, plus the sentence patterns `P`) |
| Home page content (greeting, quick actions, "Needs attention", "Explore and take action") | `02.../webapp/model/Home.js` |

No goals are pre-loaded. The full goal library of 3,204 draft goals is **not** in this package (it was a separate spreadsheet; its numbers are placeholders that HR must review).

To connect real data later: replace the in-memory `STORE` and the `LIBT` and `Scenario.js` tables with an OData service (or the SuccessFactors Goal Management API) behind a SAPUI5 model. The screens read these tables through plain functions in `Goals.js`.

## 4. What the Goals app does (version 27)

- **People and roles.** Pick "Viewing as" to be anyone from the Director General down. Goals follow the cascade DG > ED > Director > Manager > Employee.
- **Director General.** Sees **"Strategic goals"** (not "My goals"), a breadcrumb that starts at the DG, **no 3-to-5 limit**, and a New goal wizard with no role or parent step. DG goals need no approval.
- **Everyone else.** "My goals", target 3 to 5, approval by the person above, the Approvals tab for those with direct reports.
- **New goal wizard** (suggestion from the library, measure, due date, review; extra Role and Parent steps below the DG). **Push down** wizard (who, wording, date, review) for anyone with direct reports.
- **One owner per goal**, any number of contributors, team goals delivered by managers with a progress roll-up, change requests after approval.
- **Alignment** chart for the whole cascade or for a single goal, with a progress ring on every box. **Dashboard** (counts, progress by management goal, needs attention). **Approvals** queue.
- **English / Arabic switch** (top right). `I18n.js` translates the screen's own words and turns the page right to left. **Goal titles and anything typed are never translated** (the earlier Arabic-to-English goal translation was removed on purpose). Goal library suggestions and their measures stay in English because they are sample data. Arabic goal titles are always right-aligned.
- The AI parts (suggestions, matching, quality checks) are **scripted**, not a live AI.

## 5. Design

- **Look:** Al Jazeera navy and gold. Gradient header, white rounded content card, gold accents. Every colour is a CSS variable at the top of `css/goals.css` (`--grad`, `--ink`, `--muted`, `--line`, `--ok`, `--att`, `--tint`, `--orange` gold `#D89E11`, navy `#212D66`). Colours are approximate, not official brand values.
- **Fonts: the company Al Jazeera fonts only.** "AJ Latin" (Light 300, Regular 400, Bold 700, Heavy 900) and "AJ Arabic" (Light, Regular, Bold, Heavy). They are in `webapp/fonts/` (woff2, plus ttf where no woff2 was supplied), declared at the top of `css/goals.css` and `css/home.css`, and used for every element including inputs and buttons. Nothing loads from Google Fonts.
- **Header (Goals):** round gold home icon (returns to AJMN People home) on the far left, large "Goals 2027" title, language switch and role picker on the right, section tabs below.
- **Right to left:** in Arabic the root element gets `dir="rtl"` and the class `is-ar`; the CSS for it is at the bottom of `goals.css`.

## 6. Run it

**Quickest (as it runs today).** Needs Node 22.

```
cd 03-server-and-deploy
sh run-demo.sh          # builds ./demo-run with the folder layout server.mjs expects, then serves http://localhost:8080
```

`server.mjs` lists every app in its `PROJECTS` table (URL, component id, folder) and reads all of those folders at start, which is why the script assembles them first. `/` opens the AJMN People home, which opens Goals; `/goals-module/` is the Goals app on its own; the older versions keep their own addresses (for example `/goals-module-v24/`).

**In SAP Web IDE.** File > Import > From File System, import both zips (keep "Extract Archive" ticked) into the same workspace, then right-click `webapp/index.html` > Run as Web Application. **Deploy and launchpad:** follow each project's `README.txt` (ABAP repository name such as `ZAJMN_HR_GOALS`, target mapping `ZAJMNGOALS-display` and `ZAJMNHR-display`, one static tile each, both catalogs given to the users' roles).

**Anywhere else.** Open `webapp/index-standalone.html` through any web server (SAPUI5 loads from ui5.sap.com, so internet is needed).

## 7. Known limits and things to check

- **Not yet opened in SAP Web IDE or inside a Fiori launchpad.** It has been run on its own with SAPUI5 1.144 and the two apps linked.
- The browser console may show 404s for `Component-preload.js` and language files. They are optional.
- The server (`server.mjs`) and `score.yaml` are specific to the company's Canvas sandbox (sign-in, access groups). A Fiori deployment does not need them.
- Do not enter real employee data. The people, goals and the library are synthetic.
- Arabic wording was written for this prototype and should be reviewed by a native speaker before any real use. A few messages on the approval screens may still show in English.
- Open decisions are marked in the screens as `D-44` (how owner, contributor and team progress combine) and `D-50` (the goal library's numbers).

## 8. Version history of this package

Goals v27 (this package) comes from the v9 line (first with the Director General), with the new header, the DG changes, the company fonts, the English / Arabic switch and a slightly smaller title. The bilingual-goal versions v13 to v22 and the header experiments v25 and v26 are in `07-earlier-versions/`.
